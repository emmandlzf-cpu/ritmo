// ============================================================
// SINCRONIZACIÓN CON LA NUBE (Supabase)
//
// No usa la librería de Supabase a propósito: le pega directo a
// su API REST con fetch. Así la app sigue siendo un solo archivo
// sin dependencias externas, sigue abriendo sin internet y sigue
// funcionando empaquetada con Capacitor.
//
// CÓMO FUNCIONA:
// - Lo local manda. La app nunca espera a la red para responder.
// - Al entrar y cada tantos cambios, se fusiona con lo de la nube.
// - Si editaste el mismo día en dos teléfonos, gana el más
//   reciente (cada día trae su marca de tiempo).
//
// CONFIGURACIÓN: ver CONFIGURAR-SUPABASE.md
// ============================================================

const Nube = (function () {
  'use strict';

  // ⚠️ CAMBIA ESTOS DOS VALORES por los de tu proyecto.
  // Supabase → Project Settings → API
  const URL_SUPABASE = 'https://zcnhpsommwokaxibluim.supabase.co';
  const LLAVE_PUBLICA = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inpjbmhwc29tbXdva2F4aWJsdWltIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1OTc1NDMsImV4cCI6MjEwNTE3MzU0M30.iAG5aFFOlOtxHlQhArScYg_JsbfZDahyXmdNoWEvb0w';

  // Esta llave es PÚBLICA a propósito, no es un secreto filtrado:
  // está diseñada para vivir en el navegador. Lo que protege tus
  // datos son las políticas RLS de supabase/schema.sql, no la llave.
  // La que NUNCA debe salir del servidor es la "service_role".

  const CLAVE_SESION = 'sesion-nube';
  const MARGEN_RENOVAR = 60; // segundos antes de que expire

  let sesion = null;

  // --------------------------------------------------------
  // Sesión guardada
  // --------------------------------------------------------
  function cargarSesion() {
    try {
      const guardado = localStorage.getItem(CLAVE_SESION);
      sesion = guardado ? JSON.parse(guardado) : null;
    } catch { sesion = null; }
    return sesion;
  }

  function guardarSesion(datos) {
    sesion = datos;
    try {
      if (datos) localStorage.setItem(CLAVE_SESION, JSON.stringify(datos));
      else localStorage.removeItem(CLAVE_SESION);
    } catch (err) { console.error('No se pudo guardar la sesión:', err); }
  }

  const configurada = () =>
    !URL_SUPABASE.includes('TU-PROYECTO') && !LLAVE_PUBLICA.includes('TU-ANON-KEY');

  const sesionActiva = () => !!(sesion && sesion.access_token);
  const correoUsuario = () => (sesion && sesion.correo) || null;

  // --------------------------------------------------------
  // Peticiones
  // --------------------------------------------------------
  async function pedir(ruta, opciones = {}, conSesion = true) {
    if (!configurada()) throw new Error('Supabase no está configurado todavía.');

    if (conSesion) await renovarSiHaceFalta();

    const cabeceras = Object.assign({
      'apikey': LLAVE_PUBLICA,
      'Content-Type': 'application/json'
    }, opciones.headers || {});

    if (conSesion && sesion) cabeceras['Authorization'] = 'Bearer ' + sesion.access_token;

    const respuesta = await fetch(URL_SUPABASE + ruta, Object.assign({}, opciones, { headers: cabeceras }));

    if (!respuesta.ok) {
      const texto = await respuesta.text();
      throw new Error(`Supabase respondió ${respuesta.status}: ${texto.slice(0, 200)}`);
    }
    return respuesta.status === 204 ? null : respuesta.json();
  }

  async function renovarSiHaceFalta() {
    if (!sesion || !sesion.expira_en) return;
    if (Date.now() / 1000 < sesion.expira_en - MARGEN_RENOVAR) return;

    try {
      const datos = await pedir('/auth/v1/token?grant_type=refresh_token', {
        method: 'POST',
        body: JSON.stringify({ refresh_token: sesion.refresh_token })
      }, false);
      guardarSesion(desdeRespuestaAuth(datos));
    } catch (err) {
      // El refresh token venció o fue revocado: hay que volver a entrar.
      console.warn('La sesión expiró, hay que entrar de nuevo.', err.message);
      guardarSesion(null);
    }
  }

  function desdeRespuestaAuth(datos) {
    return {
      access_token: datos.access_token,
      refresh_token: datos.refresh_token,
      expira_en: Math.floor(Date.now() / 1000) + (datos.expires_in || 3600),
      correo: datos.user ? datos.user.email : (sesion && sesion.correo) || null,
      id: datos.user ? datos.user.id : (sesion && sesion.id) || null
    };
  }

  // --------------------------------------------------------
  // Entrar
  // --------------------------------------------------------
  // --------------------------------------------------------
  // PROTECCIÓN CONTRA "ENLACES PUESTOS POR OTRO"
  // Antes, cualquier URL con #access_token=... iniciaba sesión sin más.
  // Un atacante podía mandarte un enlace con SU propio token: tú quedabas
  // dentro de SU cuenta, y la app subía TUS tareas a ella. Ahora:
  //  1) Un enlace sólo se acepta si TÚ pediste entrar hace poco desde este
  //     mismo dispositivo ("login pendiente", un solo uso, 2 horas).
  //  2) Si pediste entrar con un correo, la cuenta que de verdad entra
  //     tiene que ser esa; si no, se rechaza y se cierra la sesión.
  // --------------------------------------------------------
  const CLAVE_PENDIENTE = 'login-pendiente';
  const CLAVE_ULTIMO_ENVIO = 'login-ultimo-envio';
  const VIGENCIA_PENDIENTE_MS = 2 * 60 * 60 * 1000;
  const ESPERA_ENTRE_ENVIOS_MS = 60 * 1000;
  let enlaceRechazadoFlag = false;

  function marcarPendiente(correo) {
    try { localStorage.setItem(CLAVE_PENDIENTE, JSON.stringify({ t: Date.now(), correo: correo || null })); } catch { /* sin storage */ }
  }
  function leerPendiente() {
    try {
      const p = JSON.parse(localStorage.getItem(CLAVE_PENDIENTE) || 'null');
      return (p && typeof p.t === 'number' && Date.now() - p.t < VIGENCIA_PENDIENTE_MS) ? p : null;
    } catch { return null; }
  }
  function borrarPendiente() {
    try { localStorage.removeItem(CLAVE_PENDIENTE); } catch { /* nada */ }
  }

  // Enlace mágico: no hay contraseña que robar ni que olvidar.
  async function enviarEnlace(correo) {
    // Freno para no usar tu cuenta como cañón de correos hacia terceros ni
    // agotar el cupo de envíos de Supabase.
    let ultimo = 0;
    try { ultimo = parseInt(localStorage.getItem(CLAVE_ULTIMO_ENVIO) || '0', 10) || 0; } catch { /* nada */ }
    if (Date.now() - ultimo < ESPERA_ENTRE_ENVIOS_MS) throw new Error('ESPERA');

    // OJO: el redirect va en la URL (?redirect_to=), no en el cuerpo. En el
    // cuerpo (como lo usa la librería oficial) la API REST lo ignora y mandaba
    // al "Site URL" de Supabase.
    const destino = encodeURIComponent(location.origin + location.pathname);
    await pedir('/auth/v1/otp?redirect_to=' + destino, {
      method: 'POST',
      body: JSON.stringify({ email: correo, create_user: true })
    }, false);

    try { localStorage.setItem(CLAVE_ULTIMO_ENVIO, String(Date.now())); } catch { /* nada */ }
    marcarPendiente(correo);
  }

  // Entrar tecleando el código de 6 dígitos del correo (en vez del enlace).
  // No pasa ningún token por la URL, y funciona en la app instalada del
  // iPhone, donde el enlace abre Safari y la sesión se quedaba allá.
  // Requiere que la plantilla del correo en Supabase incluya {{ .Token }}.
  async function verificarCodigo(correo, codigo) {
    const limpio = String(codigo || '').replace(/\s+/g, '');
    if (!/^\d{6,10}$/.test(limpio)) throw new Error('CODIGO_INVALIDO');
    const datos = await pedir('/auth/v1/verify', {
      method: 'POST',
      body: JSON.stringify({ type: 'email', email: correo, token: limpio })
    }, false);
    guardarSesion(desdeRespuestaAuth(datos));
    borrarPendiente();
  }

  // Requiere configurar Apple como proveedor en Supabase, y eso
  // necesita la cuenta de Apple Developer.
  function entrarConApple() {
    marcarPendiente(null); // sin correo esperado: Apple puede darte un correo privado
    const destino = encodeURIComponent(location.origin + location.pathname);
    location.href = `${URL_SUPABASE}/auth/v1/authorize?provider=apple&redirect_to=${destino}`;
  }

  // Al volver del correo, Supabase deja los tokens en el # de la URL.
  function procesarRedireccion() {
    if (!location.hash || location.hash.length < 2) return false;

    const parametros = new URLSearchParams(location.hash.slice(1));
    const access = parametros.get('access_token');
    if (!access) return false;

    // Se limpia la URL SIEMPRE (se acepte o no) para que los tokens no queden
    // a la vista ni en el historial del navegador.
    const refresh = parametros.get('refresh_token');
    const expiraEn = parseInt(parametros.get('expires_in') || '3600', 10);
    history.replaceState(null, '', location.pathname + location.search);

    const pendiente = leerPendiente();
    if (!pendiente) {
      // Nadie pidió entrar desde aquí: no es nuestro enlace. Se ignora.
      enlaceRechazadoFlag = true;
      return false;
    }
    borrarPendiente(); // un solo uso

    guardarSesion({
      access_token: access,
      refresh_token: refresh,
      expira_en: Math.floor(Date.now() / 1000) + (Number.isFinite(expiraEn) ? expiraEn : 3600),
      correo: null,
      id: null,
      correoEsperado: pendiente.correo || null
    });
    return true;
  }

  const enlaceRechazado = () => enlaceRechazadoFlag;

  async function traerUsuario() {
    if (!sesionActiva()) return null;
    let usuario;
    try {
      usuario = await pedir('/auth/v1/user', { method: 'GET' });
    } catch (err) {
      // Token inválido o revocado: no se queda una sesión "activa" que falla.
      if (/respondió (401|403)/.test(err.message)) guardarSesion(null);
      throw err;
    }

    // La cuenta que entró tiene que ser la del correo que pediste.
    const esperado = sesion && sesion.correoEsperado;
    if (esperado && String(usuario.email || '').toLowerCase() !== String(esperado).toLowerCase()) {
      guardarSesion(null);
      enlaceRechazadoFlag = true;
      throw new Error('CUENTA_DISTINTA');
    }

    guardarSesion(Object.assign({}, sesion, { correo: usuario.email, id: usuario.id, correoEsperado: null }));
    return usuario;
  }

  async function salir() {
    try {
      if (sesionActiva()) await pedir('/auth/v1/logout', { method: 'POST' });
    } catch (err) {
      console.warn('No se pudo cerrar sesión en el servidor:', err.message);
    }
    guardarSesion(null);
    borrarPendiente();
  }

  // Borra la cuenta y TODO lo que tiene en la nube (perfil y días). Apple
  // exige poder hacerlo desde la app. Llama a la función SQL
  // borrar_mi_cuenta() de supabase/schema.sql, que sólo puede borrar al
  // usuario que la invoca (auth.uid()), nunca a otro.
  async function borrarCuenta() {
    if (!sesionActiva()) throw new Error('No hay sesión iniciada.');
    await pedir('/rest/v1/rpc/borrar_mi_cuenta', { method: 'POST', body: '{}' });
    guardarSesion(null); // la cuenta ya no existe: se olvida la sesión local
  }

  // --------------------------------------------------------
  // Bajar y subir
  // --------------------------------------------------------
  async function bajar() {
    const perfiles = await pedir('/rest/v1/perfiles?select=*', { method: 'GET' });
    const dias = await pedir('/rest/v1/dias?select=fecha,tareas,actualizado&order=fecha.desc&limit=400', { method: 'GET' });

    const porFecha = {};
    dias.forEach(d => { porFecha[d.fecha] = { tasks: d.tareas, actualizado: d.actualizado }; });

    return { perfil: perfiles[0] || null, days: porFecha };
  }

  async function subirPerfil(registro) {
    await pedir('/rest/v1/perfiles', {
      method: 'POST',
      headers: { 'Prefer': 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify({
        id: sesion.id,
        nombre: registro.name || null,
        telefono: (registro.config && registro.config.phone) || null,
        meta_diaria: registro.goal || 5,
        limite_horas: registro.limitHours || 4,
        config: registro.config || {}
      })
    });
  }

  async function subirDias(days, soloEstas) {
    const filas = Object.keys(days)
      .filter(fecha => !soloEstas || soloEstas.has(fecha))
      .map(fecha => ({
        usuario_id: sesion.id,
        fecha: fecha,
        tareas: days[fecha].tasks || []
      }));

    if (!filas.length) return;

    // De 50 en 50 para no mandar una petición gigante.
    for (let i = 0; i < filas.length; i += 50) {
      await pedir('/rest/v1/dias', {
        method: 'POST',
        headers: { 'Prefer': 'resolution=merge-duplicates,return=minimal' },
        body: JSON.stringify(filas.slice(i, i + 50))
      });
    }
  }

  // --------------------------------------------------------
  // Fusión
  // Día por día gana el más reciente. Nunca se borra un día que
  // sólo existe de un lado: se conservan los dos.
  // --------------------------------------------------------
  function fusionar(local, remoto) {
    const resultado = Object.assign({}, local);
    resultado.days = Object.assign({}, local.days);
    const porSubir = new Set();

    Object.keys(remoto.days).forEach(fecha => {
      const mio = local.days[fecha];
      const suyo = remoto.days[fecha];

      if (!mio) {
        resultado.days[fecha] = { tasks: suyo.tasks, actualizado: suyo.actualizado };
        return;
      }

      const fechaMia = Date.parse(mio.actualizado || 0) || 0;
      const fechaSuya = Date.parse(suyo.actualizado || 0) || 0;

      if (fechaSuya > fechaMia) {
        resultado.days[fecha] = { tasks: suyo.tasks, actualizado: suyo.actualizado };
      } else if (fechaMia > fechaSuya) {
        porSubir.add(fecha);
      }
    });

    // Lo que sólo existe aquí, se sube.
    Object.keys(local.days).forEach(fecha => {
      if (!remoto.days[fecha]) porSubir.add(fecha);
    });

    // El perfil: si en la nube hay nombre y aquí no, se toma.
    if (remoto.perfil) {
      if (!resultado.name && remoto.perfil.nombre) resultado.name = remoto.perfil.nombre;
      if (remoto.perfil.meta_diaria && !local.goal) resultado.goal = remoto.perfil.meta_diaria;
      if (remoto.perfil.limite_horas && !local.limitHours) resultado.limitHours = remoto.perfil.limite_horas;
    }

    return { registro: resultado, porSubir: porSubir };
  }

  // --------------------------------------------------------
  // Lo que usa la app
  // --------------------------------------------------------
  async function sincronizar(registroLocal) {
    if (!configurada() || !sesionActiva()) return null;
    if (!sesion.id) await traerUsuario();

    const remoto = await bajar();
    const { registro, porSubir } = fusionar(registroLocal, remoto);

    await subirPerfil(registro);
    await subirDias(registro.days, porSubir);

    return registro;
  }

  cargarSesion();

  return {
    configurada,
    sesionActiva,
    correoUsuario,
    enviarEnlace,
    verificarCodigo,
    entrarConApple,
    procesarRedireccion,
    enlaceRechazado,
    traerUsuario,
    salir,
    borrarCuenta,
    sincronizar,
    fusionar // expuesto para poder probarlo
  };
})();
