// Arma la carpeta www/ con SÓLO lo que lleva la app de iPhone.
//
// Capacitor empaqueta lo que haya en `webDir` (www/). Antes apuntaba a "." y
// habría metido en la app los documentos, el SQL, las herramientas y hasta la
// carpeta ios/. Aquí se copia únicamente lo necesario.
//
// El service worker (sw.js) NO va: dentro de la app nativa no se usa, los
// archivos ya viven en el teléfono.
//
// Uso:  npm run build:web
import { cpSync, rmSync, mkdirSync, existsSync } from 'node:fs';

const salida = 'www';
const archivos = ['index.html', 'sync.js', 'screentime.js', 'manifest.webmanifest'];
const carpetas = ['iconos'];

rmSync(salida, { recursive: true, force: true });
mkdirSync(salida, { recursive: true });

for (const archivo of archivos) {
  if (!existsSync(archivo)) throw new Error(`Falta ${archivo}: ¿corriste esto desde la carpeta del proyecto?`);
  cpSync(archivo, `${salida}/${archivo}`);
}
for (const carpeta of carpetas) {
  if (!existsSync(carpeta)) throw new Error(`Falta la carpeta ${carpeta}/`);
  cpSync(carpeta, `${salida}/${carpeta}`, { recursive: true });
}

console.log(`Listo: ${salida}/ armada con ${archivos.length} archivos y ${carpetas.length} carpeta(s).`);
