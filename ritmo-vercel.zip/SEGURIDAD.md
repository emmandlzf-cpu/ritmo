# Seguridad — qué se revisó y qué falta

Auditorías de julio y octubre de 2026. Léelo antes de lanzar.

## Auditoría de octubre de 2026 — qué se encontró y se corrigió

| # | Hallazgo | Gravedad | Corrección |
|---|----------|----------|------------|
| 1 | **El CORS se abría solo** si no configurabas `ALLOWED_ORIGINS`: cualquier página web podía gastar tu cuota de IA desde el navegador de sus visitantes. | Alta | Por defecto sólo se permite el **mismo sitio** que sirve la app. `localhost` sólo fuera de producción. |
| 2 | **El límite por IP se podía falsear** (se tomaba el primer valor de `X-Forwarded-For`, que escribe el cliente). | Alta | Se usa `x-vercel-forwarded-for` / `x-real-ip` (los pone la plataforma) o el **último** valor de `X-Forwarded-For`. |
| 3 | **Sin tope global**: con muchas IPs (un bot) se vaciaba tu cuota de NVIDIA. | Alta | Tope global diario (`LIMITE_GLOBAL_DIA`, 3000 por defecto) en memoria y en Upstash. |
| 4 | **Las métricas del cliente iban casi crudas al prompt de la IA** (inyección de instrucciones). | Media | Se reconstruyen campo por campo (tipo, rango, largo; sin saltos de línea ni comillas invertidas). Las acciones que devuelve el modelo también se filtran en el servidor. |
| 5 | **Inicio de sesión: un enlace con el token de un atacante te metía en SU cuenta** y la app subía TUS tareas a ella. | Alta | Un enlace sólo vale si **tú lo pediste** desde este dispositivo (un solo uso, 2 h) y la cuenta que entra debe ser la del correo que escribiste. Si no, se rechaza, se cierra la sesión y no se sube nada. |
| 6 | **CSP demasiado permisiva**: permitía conectarse a *cualquier* `*.vercel.app` y `*.supabase.co` (un atacante tiene uno propio para recibir datos robados). | Media | `connect-src` sólo a la propia app y a **tu** proyecto de Supabase. También en una etiqueta `<meta>` dentro de `index.html`, para hostings sin cabeceras (GitHub Pages). Se añadió `object-src 'none'`, COOP/CORP y más. |
| 7 | **Datos guardados y de la nube sin validar** (un `repeat: "constructor"` hacía tronar pantallas; textos gigantes). | Media | `sanearRegistro()` reconstruye todo con tipo, rango y largo, al cargar y tras cada sincronización. |
| 8 | **Selectores CSS armados con texto guardado** (podían lanzar excepción y dejar el onboarding a medias). | Baja | Se compara el valor en vez de armar un selector. |
| 9 | **Acciones del coach sin validar su forma**: un `label` que no fuera texto lanzaba un error y **dejaba el chat bloqueado**; sin tope a borrados. | Media | Se normalizan, sólo tipos conocidos, y máximo 3 tareas borradas por respuesta. |
| 10 | **Dominio de ejemplo** (`TU-PROYECTO.vercel.app`) en la app nativa: cualquiera lo podía registrar y recibir tus tareas. | Media | Mientras siga siendo el ejemplo, no se usa (coach local). |
| 11 | **Pedir el correo de acceso sin freno**: spam a terceros y agotar tu cupo de correos. | Baja | Una vez por minuto desde el cliente (el freno real es el de Supabase + CAPTCHA, ver abajo). |
| 12 | **Base de datos sin límites** de tamaño ni de filas por usuario; el público anónimo tenía permisos por defecto sobre las tablas. | Media | `supabase/schema.sql`: constraints de tamaño, tope de 1500 días por cuenta, `revoke` al anónimo y `search_path` vacío en las funciones privilegiadas. |
| 13 | **Faltaba `.gitignore`** (ibas a subir a GitHub). | Baja | Ya está: `.env`, llaves, certificados, etc. nunca se suben. |
| 14 | El `redirect_to` del enlace mágico iba en el cuerpo, donde la API REST lo ignora. | Baja | Va en la URL, como exige la API. |

Verificado con pruebas simuladas (no se pudo probar contra Supabase ni Vercel reales): rechazo de orígenes ajenos, falsificación de IP, tope global, filtro de métricas y de acciones, enlace trampa, cuenta equivocada, enlace viejo, freno de envíos, código de 6 dígitos, token vencido, registro hostil en el almacenamiento y service worker.

### Lo que TIENES que hacer por tu lado (no se puede hacer desde el código)
1. **Volver a correr `supabase/schema.sql` completo** en Supabase (SQL Editor). Trae los límites nuevos y la función de borrar cuenta. **Ese SQL no se pudo probar contra una base real**: si Supabase marca un error, mándalo.
2. **Activar CAPTCHA en Supabase** (Authentication → Attack Protection). Es la defensa real contra quien pida correos de acceso a montones.
3. **Para entrar con código de 6 dígitos**, edita la plantilla del correo en Supabase (Authentication → Emails → "Magic Link") y agrega una línea con `{{ .Token }}`, por ejemplo: `Tu código: {{ .Token }}`. Sin eso el correo sólo trae el enlace.
4. En Vercel, opcional: `LIMITE_GLOBAL_DIA` (tope de peticiones al coach por día; 3000 por defecto) y, ya recomendado antes, Upstash para que los límites se compartan entre instancias.

### Riesgos que siguen y por qué
- **La CSP todavía permite `'unsafe-inline'`** en scripts: la app usa manejadores `onclick` dentro del HTML. Hoy no hay forma de meter HTML ajeno (todo entra por `textContent`), pero si algún día hubiera un XSS, la CSP no lo frenaría. Quitarlo exige mover todos los `onclick` a código y es un trabajo aparte.
- **`registro.premium` vive en el dispositivo**: quien edite su almacenamiento se lo activa. Los topes del plan gratis son de experiencia, no de seguridad. Antes de cobrar hay que validar el recibo de Apple en un servidor.
- **El coach no exige sesión**: lo protegen los límites por IP y el tope global, no una cuenta. Lo siguiente sería exigir el token de Supabase y poner cuota por usuario.
- **GitHub Pages no permite cabeceras**: ahí sólo protege la etiqueta `<meta>` (sin `frame-ancestors`, así que la app se podría incrustar en otra página). En Vercel sí están todas.
- **La sesión vive en `localStorage`** (lo normal en apps web); es lo que un XSS robaría.
- **El teléfono se guarda en la nube** (protegido por RLS) pero la app no lo usa para nada. Quítalo o decláralo en la política de privacidad.
- **Dependencias de Capacitor** (sólo para la versión nativa): sin archivo de bloqueo y sin revisar con `npm audit` (no hay Node instalado aquí). Hazlo cuando compiles la app de iOS.
- **Si compilas la app nativa**, agrega tu dominio del coach en `connect-src` (etiqueta `<meta>` de `index.html`) o el coach no podrá conectarse.

## Lo que ya quedó protegido

### El endpoint del coach (`/api/coach`)
Era el hueco más grande: estaba abierto a cualquiera. Ahora tiene:

- **Límite de peticiones por IP:** 15 por minuto y 300 por día. Quien pase
  del límite recibe un 429 y espera.
- **CORS bloqueado:** sólo responde a tus dominios (variable `ALLOWED_ORIGINS`)
  y a la app de iOS. Otros sitios web no pueden usar tu endpoint.
- **Topes de tamaño:** cuerpo máx. 40 KB, mensajes recortados, métricas
  máx. 6 KB. No se puede mandar una petición gigante para tumbar la función.
- **Timeout de 20 s** a NVIDIA: la función no se queda colgada (y pagando).
- **Anti prompt-injection:** el system prompt le dice al modelo que ignore
  instrucciones metidas en los mensajes del usuario.

### La app web
- **Sin XSS:** todo lo que escribe el usuario o devuelve la IA entra por
  `textContent`, nunca por `innerHTML`. Se revisó cada uso.
- **Cabeceras de seguridad** (`vercel.json`): anti-clickjacking
  (`X-Frame-Options: DENY`), `nosniff`, HSTS, y una CSP que limita a dónde
  puede conectarse la app (sólo a sí misma y a Supabase).
- **Archivos internos ocultos** (`.vercelignore`): las notas (`*.md`), el
  esquema SQL y las herramientas ya NO se publican. Antes cualquiera podía
  leer `LANZAMIENTO.md` y ver tus pendientes de seguridad.

### La base de datos
- **RLS activo:** cada quien sólo puede leer y escribir SUS datos, forzado
  por la base misma (ver `supabase/schema.sql`). La llave pública no sirve
  para ver datos de otros.

## Lo que TIENES que hacer antes de lanzar

1. **Configurar el límite de peticiones serio (Upstash).** El límite
   funciona con un respaldo en memoria, pero en serverless cada instancia
   tiene su propia memoria, así que un atacante decidido lo esquiva. Para
   protección real:
   - Crea una base gratis en <https://upstash.com> (Redis).
   - Copia `UPSTASH_REDIS_REST_URL` y `UPSTASH_REDIS_REST_TOKEN`.
   - Pégalas en Vercel → Settings → Environment Variables.
   - Listo: el código las detecta solo y las usa.

2. **Poner `ALLOWED_ORIGINS`** en Vercel si tu app se sirve desde más de un
   dominio, separados por coma: `https://tuapp.vercel.app,https://tudominio.com`.
   Si no lo pones, el coach sólo responde al mismo sitio que sirve la app
   (desde octubre de 2026 el valor por defecto es el seguro).

3. **Borrado de cuenta desde la app.** Ya existe (Configuración → Tu cuenta),
   pero necesita haber corrido `supabase/schema.sql`. Pruébalo con una cuenta
   de prueba antes de publicar.

4. **Revisar que RLS diga `true`** con la consulta al final de `schema.sql`.

## Lo que se decidió dejar así (y por qué)

- **La sesión se guarda en `localStorage`.** Es lo normal en apps web. El
  riesgo sería que un XSS la robara, pero no hay vector de XSS. Aceptable.
- **La llave `anon` de Supabase es visible.** Es pública por diseño; lo que
  protege los datos es RLS, no esconder la llave.
- **CORS no frena a `curl`.** CORS sólo aplica a navegadores. Contra scripts
  el que protege es el límite de peticiones. Por eso los dos importan.

## Qué vigilar ya en producción

- Los logs de Vercel: si ves muchos 429, alguien está tratando de abusar.
- El gasto de NVIDIA la primera semana, para calibrar los límites.
- Considera gatear el coach detrás de la suscripción: así un usuario gratis
  no te gasta cuota de IA sin pagarte.
