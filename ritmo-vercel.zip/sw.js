// Service worker: hace que la app abra sin internet.
//
// Estrategia:
// - Los archivos de la app se guardan en caché al instalar y se sirven
//   desde ahí (rápido y funciona offline).
// - /api/coach NUNCA se cachea: siempre va a la red, porque cada
//   respuesta del coach es distinta.
//
// Al cambiar cualquier archivo, sube el número de VERSION. Si no, la
// gente se queda con la versión vieja guardada en su teléfono.

const VERSION = 'v4';
const CACHE = `ritmo-${VERSION}`;

const ARCHIVOS = [
  './',
  './index.html',
  './sync.js',
  './screentime.js',
  './manifest.webmanifest',
  './iconos/icon-180.png',
  './iconos/icon-192.png',
  './iconos/icon-512.png'
];

self.addEventListener('install', evento => {
  evento.waitUntil(
    caches.open(CACHE)
      // addAll falla entero si un archivo no existe; así al menos
      // guardamos los que sí están.
      .then(cache => Promise.allSettled(ARCHIVOS.map(a => cache.add(a))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', evento => {
  evento.waitUntil(
    caches.keys()
      .then(nombres => Promise.all(nombres.filter(n => n !== CACHE).map(n => caches.delete(n))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', evento => {
  const url = new URL(evento.request.url);

  // El coach siempre en vivo.
  if (url.pathname.startsWith('/api/')) return;

  // Sólo manejamos GET del mismo origen.
  if (evento.request.method !== 'GET' || url.origin !== location.origin) return;

  // PRIMERO LA RED, LUEGO LA COPIA GUARDADA.
  // Antes era al revés (copia primero) y la app instalada se quedaba para
  // siempre con la primera versión que bajó, aunque subieras cambios. Así,
  // con internet siempre carga lo último y lo va guardando; sin internet
  // abre con la última copia que tenga. (Subir VERSION sigue limpiando
  // copias viejas, pero ya no es indispensable para que se actualice.)
  evento.respondWith(
    fetch(evento.request)
      .then(respuesta => {
        if (respuesta.ok && respuesta.type === 'basic') {
          const copia = respuesta.clone();
          caches.open(CACHE).then(cache => cache.put(evento.request, copia));
        }
        return respuesta;
      })
      .catch(() =>
        caches.match(evento.request).then(guardado => guardado || caches.match('./index.html'))
      )
  );
});
