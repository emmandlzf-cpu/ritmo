# Lanzar en la App Store — dónde estamos y qué falta

Esto es un mapa honesto. No está ordenado por facilidad sino por lo que
te puede detener por completo.

---

## 🔴 Los tres bloqueos de verdad

Ninguno se resuelve escribiendo más código en `index.html`. Léelos antes
de invertir tiempo o dinero.

### 1. Apple rechaza sitios web empaquetados

**Regla 4.2 — Minimum Functionality.** Si la app es tu página web dentro de
un contenedor y nada más, la rechazan. No es un rumor: es de las causas más
comunes de rechazo.

Para pasarla necesitas cosas que sólo una app puede hacer: notificaciones
reales, widget en la pantalla de inicio, funcionar sin conexión de verdad, y
—en tu caso— leer el tiempo en pantalla.

**Ya avanzamos:** la app ahora es una PWA instalable, funciona sin internet y
tiene la configuración de Capacitor lista. Eso ayuda, pero **no basta por sí solo**.

### 2. El tiempo en pantalla no lo puede leer una web. Nunca.

Esta es la función central de tu app y hoy son **datos inventados**.

Para leer el uso real del iPhone se necesita:

- El framework **`FamilyControls` + `DeviceActivity`** de Apple.
- Código **nativo en Swift** (no hay plugin de Capacitor que lo resuelva).
- Un **entitlement especial** que se le solicita a Apple por escrito, explicando
  para qué lo quieres. Lo aprueban caso por caso y **suele tardar semanas**.
  Pueden decir que no.

Además, esa API **no te deja ver "Instagram 58%"** como lo pintas hoy. Apple
protege eso a propósito: te da datos agregados y categorías, con el usuario
autorizando explícitamente. La pantalla de Estadísticas hay que rediseñarla
según lo que la API realmente entrega.

**Mientras tanto:** marqué los datos falsos con la etiqueta "datos de ejemplo"
en la app. **No los quites hasta que sean reales** — presentar datos inventados
como si fueran del usuario es rechazo seguro, y con razón.

### 3. Los $69 MXN tienen que pasar por Apple

Una suscripción a contenido digital **debe** cobrarse con In-App Purchase.
Apple se queda **30% el primer año, 15% después** (15% desde el inicio si
facturas menos de un millón de dólares al año, entrando al Small Business Program).

Mandar al usuario a pagar por fuera es rechazo inmediato.

Falta implementar StoreKit 2, crear el producto en App Store Connect, y manejar
restaurar compras — Apple lo exige y lo revisa.

---

## 💰 Lo que cuesta

| Concepto | Costo |
|---|---|
| Apple Developer Program | **$99 USD al año**, obligatorio |
| Mac con Xcode | Compilar iOS exige macOS, pero **no necesitas comprar una Mac**: GitHub Actions compila en Macs en la nube (gratis en repositorios públicos), y servicios como Codemagic tienen plan gratis. Una Mac propia sólo hace falta para depurar Swift con calma o abrir Xcode |
| Vercel | Gratis al inicio |
| NVIDIA API | Según uso — **cuidado, ver abajo** |

**Sobre la cuota de IA:** hoy `/api/coach` está abierto. Cualquiera que
encuentre la URL puede llamarlo y gastarte tu cuota. Antes de publicar hay
que ponerle un límite de peticiones por IP.

---

## ✅ Lo que ya está hecho

- [x] La app se ve bien y funciona en teléfono (pantalla completa, respeta el notch)
- [x] Instalable como PWA — `manifest.webmanifest`
- [x] Funciona sin internet — `sw.js`
- [x] Diseño del icono — `iconos/icono.svg`
- [x] Generador de los PNG en todos los tamaños — `herramientas/generar-iconos.html`
- [x] Borrador de aviso de privacidad — `PRIVACIDAD.md`
- [x] Botón para borrar todos los datos (Apple lo exige)
- [x] Configuración de Capacitor lista
- [x] La app encuentra el coach aunque esté empaquetada (`API_REMOTA`)
- [x] CORS en la función del coach
- [x] Datos falsos marcados como ejemplo
- [x] **Agregar, editar, eliminar y priorizar tareas** desde la app
- [x] **Historial de 60 días** con navegación por día
- [x] **Racha real**, calculada del historial
- [x] **Gráfica de la semana con datos reales**
- [x] Animación y vibración al completar, confeti al cerrar el día
- [x] Recordatorio diario con notificaciones del navegador
- [x] El botón de suscripción ya no finge cobrar
- [x] **Cuentas y sincronización** entre dispositivos (Supabase + enlace por correo)
- [x] Esquema de base de datos con **seguridad por renglón (RLS)**
- [x] Sign in with Apple preparado (falta la cuenta de Developer para activarlo)
- [x] **Racha que perdona** — cuenta días en que apareciste, no días perfectos
- [x] **Modo enfoque** — una tarea, temporizador corto, sin castigo por salir
- [x] **Tiempo estimado por tarea** con chequeo de realidad ("no cabe hoy")
- [x] **Partir tareas en pasos** desde el menú de la tarea (acción `split_task`)
- [x] Análisis de competencia y posicionamiento — ver `COMPETENCIA.md`
- [x] **Tareas que se repiten** — cada día / semana / mes, reaparecen solas
- [x] **Endpoint del coach protegido** — límite por IP, CORS, topes, timeout (ver `SEGURIDAD.md`)
- [x] **Cabeceras de seguridad** y `.vercelignore` (notas internas ya no se publican)
- [x] **Anti prompt-injection** en el coach
- [x] **Tiempo en pantalla: lado de la app listo** — `screentime.js` + andamiaje Swift (ver `TIEMPO-EN-PANTALLA.md`)
- [x] **Análisis de escalabilidad y cache** — ver `ESCALABILIDAD.md`
- [x] **Captura rápida (volcado mental)** — botón flotante con fechas naturales
- [x] **Agendar tareas a futuro** — navegación a días futuros editables
- [x] **Onboarding personalizado** conectado al coach — recomendaciones a la medida

## ⬜ Lo que falta

### Antes que nada
- [ ] **Decidir el nombre.** Puse `Ritmo` como marcador de posición. Está en
      `manifest.webmanifest`, `capacitor.config.json` y las etiquetas de `index.html`.
      Revisa que no esté ocupado en la App Store y que el dominio esté libre.
- [ ] Cambiar `com.TUDOMINIO.ritmo` por tu identificador real en `capacitor.config.json`
- [ ] Cambiar `https://TU-PROYECTO.vercel.app` por tu dominio en `index.html`
- [ ] Llenar `[TU NOMBRE]` y `[TU CORREO DE SOPORTE]` en `PRIVACIDAD.md`

### Iconos
Ya están generados en `iconos/` (180, 192, 512 y maskable). Si cambias el
diseño, regenera los PNG con `herramientas/generar-iconos.html`. La app de
iPhone necesitará además el icono de 1024 px en App Store Connect.

### Convertir a app de iOS (en una Mac)
```bash
npm install
npm run ios:agregar   # arma www/ y crea el proyecto de Xcode (ios/)
npm run ios:abrir     # abre Xcode (necesitas una Mac)
```
`npm run build:web` copia a `www/` sólo lo que lleva la app (antes se
empaquetaba toda la carpeta del proyecto, con documentos y SQL incluidos).

### Cuentas
- [ ] Seguir `CONFIGURAR-SUPABASE.md` (crear proyecto, correr el SQL, pegar las llaves)
- [x] **Borrado de cuenta desde dentro de la app** — hecho (requiere correr `supabase/schema.sql`)
- [ ] Conectar tu propio servicio de correo, para que los enlaces no caigan en spam

### Trabajo nativo (esto es lo grande)
- [ ] Solicitar a Apple el entitlement de **Family Controls**
- [ ] Implementar el módulo de **Screen Time** en Swift
- [ ] Rediseñar Estadísticas con los datos que la API sí entrega
- [ ] Implementar **StoreKit 2** para la suscripción
- [ ] Implementar **restaurar compras**
- [ ] Notificaciones reales (hoy los interruptores de Configuración no mandan nada)

### Para App Store Connect
- [ ] Cuenta de Apple Developer activa ($99 USD)
- [ ] Capturas de pantalla: iPhone 6.9" y 6.5" — mínimo 3, máximo 10
- [ ] Descripción, palabras clave, categoría, clasificación por edad
- [ ] **URL pública** del aviso de privacidad (sube `PRIVACIDAD.md` como página)
- [ ] URL de soporte
- [ ] Llenar el cuestionario de **App Privacy** — que coincida con la realidad
- [ ] Cuenta de prueba para el revisor, si hiciera falta
- [x] Límite de peticiones en `/api/coach` — hecho (por IP y global; ver `SEGURIDAD.md`)

---

## 📦 Sacar el archivo .ipa desde GitHub (sin tener una Mac)

El repositorio trae `.github/workflows/ipa-sin-firmar.yml`. Al correrlo
(GitHub → **Actions** → "IPA sin firmar" → **Run workflow**), una Mac de GitHub
compila la app y deja un `.ipa` descargable en esa misma corrida. **Es gratis
si el repositorio es público.** Es un primer borrador que nunca se ha
corrido: si falla, abre la corrida, copia el error y se ajusta.

Un `.ipa` **sin firmar** no se instala tal cual. Hay dos caminos:

### Camino A — gratis, para probar en TU iPhone
1. En el iPhone: Ajustes → Privacidad y seguridad → **Modo de desarrollador** (actívalo y reinicia).
2. En Windows instala **Sideloadly** o **AltStore** (con iTunes e iCloud descargados
   de apple.com, no de la Microsoft Store).
3. Conecta el iPhone, arrastra el `.ipa`, escribe tu Apple ID y listo.

Límites reales: la firma gratis **dura 7 días** (hay que volver a firmar cada
semana), máximo 3 apps así, y con Apple ID gratis **no hay** notificaciones
push, compras dentro de la app ni Family Controls (el tiempo en pantalla real).
Sirve para ver la app corriendo como app, nada más.

### Camino B — con los $99 de Apple Developer, para TestFlight y App Store
Hace falta firmar con tu certificado y tu perfil de aprovisionamiento. Se puede
hacer también sin Mac propia (con otro flujo de GitHub que usa esos datos como
"secretos", o con Codemagic, que los gestiona solo con una llave de App Store
Connect). Con eso ya se puede subir a **TestFlight** (probar con amigos, sin
límite de 7 días) y después a la App Store. Cuando tengas la cuenta, se arma.

### Lo que el .ipa NO resuelve
- **La regla 4.2 de Apple** (arriba): una app que es solo tu web empaquetada
  se rechaza para la App Store. Para TestFlight interno o para instalarla tú, no importa.
- **El coach necesita tu dominio de Vercel.** Cambia `API_REMOTA` en `index.html`
  y agrega ese dominio a `connect-src` en la etiqueta `<meta>` de `index.html`.
  Mientras siga el valor de ejemplo, la app nativa usa el coach local.
- **El identificador `com.TUDOMINIO.ritmo`** de `capacitor.config.json`: cámbialo
  por uno tuyo y único *antes* de subir a la App Store (después ya no se puede).
- **Entrar con enlace del correo no sirve en la app nativa** (el enlace abre
  Safari). Usa el **código de 6 dígitos** (ver `CONFIGURAR-SUPABASE.md`).
- **El plugin de tiempo en pantalla** (`ios-nativo/`) no se incluye en la
  compilación: necesita el permiso de Apple y nunca se ha compilado.

---

## Mi recomendación

Publicar en la App Store con la función de tiempo en pantalla es un proyecto de
varios meses que necesita Swift, una Mac y la aprobación discrecional de Apple.

**Antes de meterle eso:** publícala en Vercel como PWA. La gente puede instalarla
desde Safari en su pantalla de inicio, hoy mismo, gratis. Así compruebas si a
alguien le sirve el coach antes de pagar los $99 y pelearte con StoreKit.

Si la gente la usa, ya sabrás que vale la pena el camino nativo.
