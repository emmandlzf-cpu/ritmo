// ScreenTimePlugin.swift
// Plugin de Capacitor que le da a la app web el tiempo en pantalla real.
//
// ⚠️ ANDAMIAJE, NO ESTÁ TERMINADO. Esto compila y define la estructura,
// pero la lectura real del tiempo de uso necesita:
//   1. El entitlement "Family Controls" aprobado por Apple (se solicita
//      por escrito y tarda semanas — ver TIEMPO-EN-PANTALLA.md).
//   2. Probarse en un iPhone físico (no funciona en el simulador).
//   3. Que el usuario autorice el acceso.
//
// Se coloca en el proyecto de Xcode que genera `npx cap add ios`, dentro
// de App/App/. Necesita: import FamilyControls, DeviceActivity.
//
// Devuelve EXACTAMENTE la forma que espera screentime.js:
//   estadoPermiso -> { estado: "concedido" | "pendiente" | "negado" }
//   resumenHoy    -> { usadoMin: Int, apps: [{ nombre: String, min: Int }] }
//   resumenSemana -> { promedioMin: Int, vsSemanaPasadaPct: Int, dias: [...] }

import Foundation
import Capacitor
import FamilyControls
import DeviceActivity

@objc(ScreenTimePlugin)
public class ScreenTimePlugin: CAPPlugin {

    let centro = AuthorizationCenter.shared

    // --- Permiso -------------------------------------------------------
    @objc func estadoPermiso(_ call: CAPPluginCall) {
        let estado: String
        switch centro.authorizationStatus {
        case .approved:     estado = "concedido"
        case .denied:       estado = "negado"
        default:            estado = "pendiente"
        }
        call.resolve(["estado": estado])
    }

    @objc func pedirPermiso(_ call: CAPPluginCall) {
        Task {
            do {
                // .individual: sólo el tiempo de este usuario, no control parental.
                try await centro.requestAuthorization(for: .individual)
                call.resolve(["estado": "concedido"])
            } catch {
                call.resolve(["estado": "negado"])
            }
        }
    }

    // --- Datos ---------------------------------------------------------
    // NOTA IMPORTANTE: DeviceActivity NO entrega los totales directamente a
    // la app. El conteo ocurre en una App Extension (DeviceActivityReport)
    // que corre aislada. El patrón real es:
    //   1. Una DeviceActivityReport extension calcula los totales.
    //   2. Los guarda en un App Group compartido (UserDefaults(suiteName:)).
    //   3. Este plugin los lee de ahí.
    // Aquí se lee del App Group. La extensión es un archivo aparte que
    // falta escribir (ver TIEMPO-EN-PANTALLA.md).

    let grupoCompartido = "group.com.TUDOMINIO.ritmo"

    @objc func resumenHoy(_ call: CAPPluginCall) {
        guard let defaults = UserDefaults(suiteName: grupoCompartido),
              let datos = defaults.dictionary(forKey: "resumenHoy") else {
            call.reject("Todavía no hay datos de hoy. ¿Ya se autorizó el permiso?")
            return
        }
        call.resolve(datos)
    }

    @objc func resumenSemana(_ call: CAPPluginCall) {
        guard let defaults = UserDefaults(suiteName: grupoCompartido),
              let datos = defaults.dictionary(forKey: "resumenSemana") else {
            call.reject("Todavía no hay datos de la semana.")
            return
        }
        call.resolve(datos)
    }
}
