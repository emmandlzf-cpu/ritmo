// ScreenTimePlugin.m
// Registra el plugin de Swift ante Capacitor (que es Objective-C por dentro).
// Va junto a ScreenTimePlugin.swift en App/App/ dentro del proyecto de Xcode.
//
// Cada método aquí declarado tiene que coincidir con un @objc func del .swift.

#import <Foundation/Foundation.h>
#import <Capacitor/Capacitor.h>

CAP_PLUGIN(ScreenTimePlugin, "ScreenTime",
    CAP_PLUGIN_METHOD(estadoPermiso, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(pedirPermiso, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(resumenHoy, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(resumenSemana, CAPPluginReturnPromise);
)
