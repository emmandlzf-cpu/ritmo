// ============================================================
// PUENTE DE TIEMPO EN PANTALLA
//
// Una página web NO puede leer el uso del teléfono. Sólo lo puede hacer
// código nativo de iOS (FamilyControls + DeviceActivity) con un permiso
// especial que aprueba Apple. Ver TIEMPO-EN-PANTALLA.md.
//
// Este archivo es el CONTRATO entre la app web y ese código nativo:
// - En un navegador normal: `disponible()` es false y todo devuelve null.
//   La app muestra sus datos de ejemplo, etiquetados como tales.
// - Dentro de la app de iOS con el plugin instalado: devuelve datos
//   reales y la pantalla de Estadísticas se llena sola.
//
// El lado Swift sólo tiene que devolver objetos con ESTA forma exacta.
// Así, el día que se conecte lo nativo, no hay que tocar la interfaz.
// ============================================================

const PantallaNativa = (function () {
  'use strict';

  // El plugin nativo se registra en window.Capacitor.Plugins.ScreenTime.
  function plugin() {
    return (window.Capacitor &&
            window.Capacitor.Plugins &&
            window.Capacitor.Plugins.ScreenTime) || null;
  }

  const disponible = () => !!plugin();

  // 'no-disponible' | 'pendiente' | 'concedido' | 'negado'
  async function estadoPermiso() {
    const p = plugin();
    if (!p) return 'no-disponible';
    try {
      const { estado } = await p.estadoPermiso();
      return estado || 'pendiente';
    } catch {
      return 'pendiente';
    }
  }

  // Abre el diálogo del sistema para autorizar el acceso al tiempo de uso.
  async function pedirPermiso() {
    const p = plugin();
    if (!p) return 'no-disponible';
    try {
      const { estado } = await p.pedirPermiso();
      return estado || 'pendiente';
    } catch {
      return 'negado';
    }
  }

  // --- Contrato de datos que el lado Swift DEBE devolver ---
  //
  // resumenHoy() ->
  //   {
  //     usadoMin: 130,                     // minutos usados hoy
  //     apps: [                            // ordenadas de mayor a menor
  //       { nombre: 'Instagram', min: 75 },
  //       { nombre: 'WhatsApp',  min: 35 }
  //     ]
  //   }
  async function resumenHoy() {
    const p = plugin();
    if (!p) return null;
    try {
      const datos = await p.resumenHoy();
      return validarHoy(datos) ? datos : null;
    } catch (err) {
      console.warn('No se pudo leer el tiempo de hoy:', err.message);
      return null;
    }
  }

  // resumenSemana() ->
  //   {
  //     promedioMin: 125,
  //     vsSemanaPasadaPct: -12,            // negativo = usó menos, bueno
  //     dias: [ { fecha:'2026-07-20', min: 140 }, ... ]  // lunes a domingo
  //   }
  async function resumenSemana() {
    const p = plugin();
    if (!p) return null;
    try {
      const datos = await p.resumenSemana();
      return validarSemana(datos) ? datos : null;
    } catch (err) {
      console.warn('No se pudo leer el tiempo de la semana:', err.message);
      return null;
    }
  }

  // Nunca confiamos ciegamente en lo que llega del puente: validamos la
  // forma antes de pintarla, para no romper la pantalla con datos raros.
  function validarHoy(d) {
    return d && typeof d.usadoMin === 'number' && Array.isArray(d.apps) &&
      d.apps.every(a => a && typeof a.nombre === 'string' && typeof a.min === 'number');
  }

  function validarSemana(d) {
    return d && typeof d.promedioMin === 'number' && Array.isArray(d.dias);
  }

  return { disponible, estadoPermiso, pedirPermiso, resumenHoy, resumenSemana };
})();
