# La competencia y dónde encajas

Investigado en julio de 2026. Revísalo cada tanto: los precios cambian.

## Con quién compites de verdad

| App | Precio | Qué hace bien | Su hueco |
|---|---|---|---|
| **Tiimo** | $7.99 USD/mes · $79.99/año | El líder para TDAH. Planeador visual con línea de tiempo, íconos, bloques de color. Muy querido | Deliberadamente simple: sin subtareas, sin jerarquías, sin analítica. **Sin coach de IA** |
| **Llama Life** | $6 USD/mes | Cuenta regresiva por tarea que avanza sola a la siguiente. Ataca la parálisis de inicio. Fundadora con TDAH | Muy enfocado al temporizador; no es un sistema completo |
| **Focus Bear** | $4.99 USD/mes | Rutinas guiadas de mañana, descansos y noche | Se centra en rutinas, no en las tareas del día |
| **Goblin Tools** | Casi gratis | "Magic ToDo": parte tareas grandes en pasos. Es *la* función que la gente con TDAH ama | Herramienta suelta, sin seguimiento ni historial |
| **Finch** | Gratis + premium | Mascota virtual que cuidas haciendo tareas. Retención altísima por el vínculo emocional | Es autocuidado, no organización de verdad |
| **Sunsama** | ~$16 USD/mes | Ritual de planeación diaria + calendario. Muy completo | Caro y pesado; asume que ya eres organizado |
| **Todoist** | Gratis + ~$4/mes | Captura por lenguaje natural ("comprar leche mañana"), el estándar de tareas | Genérico, no pensado para TDAH |

## Auditoría honesta: qué hace TU app hoy

Esto es lo que de verdad tienes construido y funcionando (revisado en el código):

**Tareas:** agregar, editar, borrar, prioridad (estrella), completar, y **repetir**
(cada día/semana/mes). Se arrastran las pendientes al día siguiente.
**Modo enfoque:** una tarea a pantalla completa con temporizador de 5/15/25 min.
Es tu versión de Llama Life, pero mejor enfocada: el compromiso es *empezar*.
**Racha que perdona:** cuenta días en que apareciste, no perfectos, y aguanta un
día flojo. Esto lo hace mejor que casi todos.
**Coach de IA conversacional** con acciones reales (agrega/parte tareas, cambia
ajustes) + respaldo local sin internet + manejo de crisis. **Nadie del top lo tiene.**
**Historial de 60 días**, gráfica semanal real, navegación por día.
**Sincronización en la nube** entre dispositivos (cuenta por correo).
**Recordatorios** (por ahora sólo con la app abierta).
**Confeti y vibración** al cerrar el día. **Instalable y funciona sin internet.**

Traducción: para ser de una persona, tienes MÁS de lo que crees. El coach y la
racha perdonadora son ventajas reales que el líder (Tiimo) no tiene.

## Lo que te FALTA, ordenado por impacto real

### ✅ Alto impacto — YA HECHAS

1. **Captura rápida (volcado mental).** ✅ Botón flotante (+) siempre visible
   que abre "Suéltalo aquí": escribes, Enter, y sigue listo para la siguiente.
   Entiende fechas naturales.

2. **Agendar tareas a futuro + fechas por lenguaje natural.** ✅ "comprar
   regalo el viernes", "pagar el 30", "en 3 días". Van a su día; navegas a los
   días futuros y hoy avisa cuántas tienes programadas.

### ✅ También hecha

3. **Onboarding que conozca a la persona.** ✅ 4 preguntas al inicio (qué se
   te complica, qué quieres lograr, cuándo rindes mejor). El coach usa ese
   perfil para dar recomendaciones a la medida, no genéricas.

### 🔴 Notas del onboarding original Hoy sólo pregunta el nombre. Tiimo
   pregunta con qué batallas y adapta la app. Para ti tiene doble premio: mejor
   primera impresión Y te da datos de tu audiencia (qué les cuesta), oro para tu
   contenido.

### 🟡 Impacto medio — segunda ola

4. **Notificaciones con la app cerrada.** Hoy sólo avisan si la tienes abierta,
   lo cual para TDAH es casi inútil ("ojos que no ven..."). Necesita lo nativo
   de iOS. Ya está anotado, pero es más importante de lo que parece.

5. **Más recompensa/juego.** Tienes racha + confeti. Finch retiene muchísimo con
   su mascota. No copies la mascota, pero un sistema de logros o algo que
   "crezca" con tu constancia engancha. Con cuidado de que no se sienta infantil.

6. **Entrada por voz.** Para saltarse la fricción de teclear. La web tiene API de
   voz; en nativo es fácil. Ayuda mucho para capturar rápido.

7. **Tema claro.** La app es sólo oscura. Algunas personas lo necesitan por
   accesibilidad o gusto. Esfuerzo bajo.

### 🟢 Grande y opcional — decisión de rumbo

8. **Vista de línea de tiempo / bloques de horario.** Es la identidad ENTERA de
   Tiimo: ver el día como bloques con horas, no como lista. Es un proyecto
   grande y te llevaría hacia otro tipo de app. No lo necesitas para lanzar, pero
   es lo que más te diferenciaría de una simple lista de pendientes.

9. **Widget y Apple Watch.** Retienen mucho (la app siempre a la vista), pero son
   puro nativo y van después.

## El veredicto sin adornos

Tu app **ya compite** en lo que importa para tu nicho: coach de IA + racha sana +
español real. Eso Tiimo no lo tiene.

Pero te faltan **dos cosas básicas de cualquier gestor de tareas** que la gente
va a extrañar de inmediato: **captura rápida** y **agendar a futuro**. Sin esas,
por más bonito el coach, se siente incompleta al segundo día de uso.

Mi orden si fuera tú: captura rápida → fechas a futuro → onboarding. Con esas
tres, la app pasa de "prototipo pulido" a "producto que usaría a diario".

## Lo que esto significa para el precio

**$69 MXN ≈ $3.70 USD al mes.**

Estás **por debajo de todos**. Tiimo cuesta más del doble (~$150 MXN). Eso no
es un problema: es tu posición. Para el mercado hispanohablante, el precio
internacional es caro y la mayoría ni siquiera está traducida.

No subas el precio. El plan anual con descuento sí conviene: Tiimo empuja el
anual porque la retención mensual en apps de hábitos es baja.

## Dónde tienes ventaja real

1. **Español de verdad, no traducido.** Ninguno de los grandes está pensado
   para el mercado hispanohablante. Es el hueco más grande y más barato de
   ocupar.
2. **Coach de IA conversacional.** Tiimo, el líder, no lo tiene. Empiezan a
   salir apps con esto (Shelpful, Univi) pero nadie domina todavía.
3. **Tú traes la audiencia.** Ellos pagan anuncios; tú tienes contenido. Es
   la ventaja más difícil de copiar.
4. **Tiempo en pantalla + tareas juntos.** Nadie combina las dos cosas.
   Sigue siendo tu apuesta a largo plazo (y la que necesita Swift).

## Dónde estás abajo

- **Sin vista de línea de tiempo / calendario.** Es el corazón de Tiimo.
- **Sin rutinas repetidas.** Las tareas se arrastran del día anterior, pero
  no hay "todos los lunes".
- **Sin widget ni Apple Watch.**
- **Sin comunidad.** Finch y Numo retienen con eso.

## Lo que ya copiaste bien (y mejoraste)

- El temporizador por tarea de Llama Life → **modo enfoque**, pero con la
  diferencia de que aquí el compromiso es *empezar*, no terminar.
- El partir tareas de Goblin Tools → **acción `split_task` del coach**, y
  aquí sí queda guardado en tu día.
- La estimación de tiempo → **con chequeo de realidad**: te avisa cuando lo
  que planeaste no cabe en el día. Eso no lo hace ninguno de los cuatro.

## El posicionamiento

No es "una app de organización". Compites con Todoist gratis y pierdes.

Es **la app de organización para cerebros con TDAH, en español, con un coach
que te ayuda a empezar.**

⚠️ **Cuidado legal:** puedes decir "diseñada para cómo funciona tu cerebro" o
"pensada para TDAH". **No** puedes decir que trata, mejora o reduce el TDAH:
eso es lenguaje médico, Apple lo revisa y te rechaza.

## Fuentes

- <https://lifestack.ai/blog/adhd-apps-for-focus>
- <https://www.morgen.so/blog-posts/adhd-productivity-apps>
- <https://habi.app/insights/best-adhd-planner-apps/>
- <https://www.tiimoapp.com/reviews>
- <https://blog.rivva.app/p/ai-assistants-for-adhd>
