# Conectar la sincronización con cuentas

Unos 15 minutos. Sin esto la app funciona igual, pero sólo guarda en el
teléfono donde estás.

---

## 1. Crear el proyecto

1. Entra a <https://supabase.com> y crea una cuenta (el plan gratis alcanza
   de sobra para empezar).
2. **New project**. Ponle nombre, elige una contraseña para la base de datos
   (guárdala en tu gestor de contraseñas, no la vas a usar en la app) y
   escoge la región **East US** o la más cercana a tus usuarios.
3. Tarda unos minutos en levantar.

## 2. Crear las tablas

1. En el menú de la izquierda: **SQL Editor** → **New query**.
2. Abre `supabase/schema.sql` de este proyecto, copia **todo** el contenido
   y pégalo ahí.
3. **Run**.
4. Al final del archivo viene una consulta para comprobar que la seguridad
   quedó bien. Córrela. Las dos tablas deben decir `rowsecurity = true`.

> ⚠️ Si alguna dice `false`, **no subas la app**. Sin esa protección,
> cualquiera podría leer las tareas y los teléfonos de todos tus usuarios.

> **Si ya habías corrido el SQL antes**, vuelve a correrlo completo: se puede
> repetir sin romper nada y ahora incluye la función `borrar_mi_cuenta()`
> (para el botón "Eliminar mi cuenta" de la app, que Apple exige). Sin esa
> función el botón avisa que no pudo borrar y no toca nada.

## 3. Copiar tus llaves a la app

1. **Project Settings** (el engrane) → **API**.
2. Copia estos dos valores:
   - **Project URL** → algo como `https://abcdefgh.supabase.co`
   - **anon public** → una cadena larguísima que empieza con `eyJ...`
3. Ábrelos en `sync.js` (arriba del archivo) y reemplaza:

```js
const URL_SUPABASE = 'https://TU-PROYECTO.supabase.co';
const LLAVE_PUBLICA = 'TU-ANON-KEY';
```

**Sobre la llave `anon`:** es pública a propósito y va a estar a la vista de
cualquiera que abra tu app. No es una filtración. Lo que protege tus datos
son las políticas RLS del paso 2.

**La que NUNCA debe salir del servidor** es la que dice `service_role`. Esa
se salta todas las protecciones. No la pongas en `sync.js` ni en ningún
archivo que llegue al navegador.

## 4. Decirle a Supabase a dónde regresar

Cuando alguien abre el enlace de su correo, Supabase lo manda de vuelta a tu
app. Hay que autorizar esa dirección o el enlace no funciona.

1. **Authentication** → **URL Configuration**.
2. En **Site URL** pon la dirección de tu app (Vercel o GitHub Pages):
   `https://tu-proyecto.vercel.app`. **Importante:** si la sirves desde otro
   dominio, también hay que cambiarlo en `connect-src` de `vercel.json` y de
   la etiqueta `<meta>` de `index.html` (sólo se permite hablar con TU proyecto
   de Supabase).
3. En **Redirect URLs** agrega, una por línea:
   ```
   https://tu-proyecto.vercel.app
   https://tu-proyecto.vercel.app/index.html
   http://localhost:3000
   ```

### Para poder entrar con el código de 6 dígitos (recomendado en iPhone)
En Supabase → **Authentication → Emails → Magic Link**, agrega al correo una
línea con el código, por ejemplo `<p>Tu código: {{ .Token }}</p>`, y deja el
enlace. Así la gente puede escribir el código dentro de la app instalada (el
enlace del correo abre Safari, no la app instalada). Y activa el **CAPTCHA**
en Authentication → Attack Protection para que nadie pueda usar tu proyecto
para mandar correos a montones.

## 5. Probarlo

1. Sube los cambios a Vercel.
2. Abre la app → **Perfil** → engranaje → **Tu cuenta**.
3. Escribe tu correo y presiona **Enviarme un enlace**.
4. Revisa tu correo y abre el enlace: debe volver a la app ya con la sesión.
5. Marca una tarea. Abre la app en otro navegador o teléfono, entra con el
   mismo correo, y ahí debe estar.

> El correo de Supabase por defecto llega desde una dirección genérica y a
> veces cae en spam. Para producción conviene conectar tu propio servicio de
> correo en **Authentication → Emails**.

---

## Iniciar sesión con Apple

El botón ya está en la app pero **necesita la cuenta de Apple Developer**
($99 USD al año), que todavía no tienes. Cuando la tengas:

1. En tu cuenta de Apple: crea un **Services ID** y una **llave Sign in with
   Apple**.
2. En Supabase: **Authentication → Providers → Apple**, activa y pega el
   Services ID, el Team ID, el Key ID y la llave privada.
3. Agrega la URL de retorno de Supabase en la configuración de Apple.

Hasta entonces el botón avisa que falta configurarlo, en vez de fallar en
silencio.

---

## Cómo funciona la sincronización

- **Lo local manda.** La app nunca espera a la red para responder: marcas una
  tarea y se ve al instante, haya internet o no.
- Los cambios se suben **3 segundos después** del último movimiento, así que
  marcar cinco tareas seguidas manda una sola petición.
- También sincroniza al abrir la app y al volver a ella.
- **Si editaste el mismo día en dos teléfonos, gana el más reciente.** Cada
  día guarda su hora de modificación.
- **Nunca se borra un día que sólo existe de un lado.** Si un teléfono tiene
  días que el otro no, se conservan los dos.

## Qué falta (con honestidad)

- **Borrado de cuenta:** ya existe (Configuración → Tu cuenta → "Eliminar mi
  cuenta"), pero requiere haber corrido `supabase/schema.sql` con la función
  `borrar_mi_cuenta()`. Pruébalo con una cuenta de prueba antes de publicar.
- **No hay resolución de conflictos por tarea**, sólo por día completo. Si
  agregas una tarea en un teléfono y otra distinta en otro el mismo día,
  gana la lista del que guardó al último.
- **Sin límite de peticiones.** Supabase tiene protecciones básicas, pero
  conviene revisar el uso al principio.
