# Escalabilidad — ¿aguanta muchos usuarios a la vez?

Análisis de la arquitectura pensando en crecer sin que se ponga lenta ni
se corrompan datos.

## Resumen: aguanta bien, por cómo está armada

La app tiene tres piezas y las tres escalan casi solas:

| Pieza | Cómo escala | Riesgo |
|---|---|---|
| **App web** (HTML/JS) | Archivos estáticos servidos por el CDN de Vercel. Da igual 100 o 100,000 usuarios: el CDN los reparte | Ninguno |
| **Coach** (`/api/coach`) | Función serverless: Vercel crea más instancias solas según la demanda | El costo y el límite de NVIDIA, no la velocidad |
| **Base de datos** (Supabase) | Cada usuario toca sólo sus propias filas. No hay un recurso compartido que se trabe | Conexiones concurrentes en el plan gratis |

**No hay un servidor central que se sature.** Ese es el punto clave: nada
mantiene estado en memoria entre usuarios, así que no hay cuello de botella
que se caliente con muchos a la vez.

## Por qué NO se pone lenta

- **La app nunca espera a la red para responder.** Marcas una tarea y se ve
  al instante: primero se pinta y se guarda local, la nube se actualiza
  después, en segundo plano. Aunque Supabase tarde, la app se siente rápida.
- **La sincronización va agrupada.** Marcar cinco tareas seguidas manda una
  sola petición (espera 3 s tras el último cambio), no cinco. Menos carga.
- **Las consultas están indexadas.** La tabla `dias` tiene índice por
  `(usuario_id, fecha)`, así que "dame mis últimos 60 días" es instantáneo
  aunque la tabla tenga millones de filas de todos los usuarios.

## Por qué NO se corrompe

- **Cada día es su propia fila** con su marca de tiempo. Dos teléfonos
  editando el mismo día → gana el más reciente, y **nunca se pierde un día
  que sólo existe de un lado**. Ver la fusión en `sync.js`.
- **`localStorage` es la fuente de verdad local.** Si falla la nube, tus
  datos siguen intactos en el teléfono. La nube es respaldo, no el original.
- **RLS impide el cruce de datos** a nivel base: es imposible que un usuario
  escriba encima de otro, aunque el código tuviera un error.

## Dónde está el cache

1. **Service worker (`sw.js`):** guarda la app en el teléfono. Abre sin
   internet y no vuelve a bajar los archivos cada vez. → Sube el número de
   `VERSION` en `sw.js` cada vez que cambies algo, si no la gente se queda
   con la versión vieja.
2. **CDN de Vercel:** cachea los archivos estáticos cerca de cada usuario.
3. **`localStorage`:** el estado del usuario, para no depender de la red.

**Lo que NUNCA se cachea:** las respuestas del coach (`/api/coach`). Cada
una es distinta, y el service worker las deja pasar siempre a la red.

## Límites reales por plan (cuándo hay que pagar)

| Servicio | Plan gratis aguanta | Cuándo subir |
|---|---|---|
| Vercel | ~100 GB de tráfico/mes | Miles de usuarios activos |
| Supabase | 500 MB de datos, 50k usuarios activos/mes | Al crecer, ~$25 USD/mes |
| NVIDIA | Créditos de prueba | Desde el primer momento serio (ver costos abajo) |
| Upstash | 10,000 comandos/día | Con mucho tráfico al coach |

## Optimizaciones que NO hacen falta todavía (pero existen si crece)

- **Sincronización incremental:** hoy la app baja los últimos 90 días en cada
  sync. Es barato (son pocos KB), pero con años de historial convendría bajar
  sólo lo que cambió desde la última vez. Fácil de agregar cuando pese.
- **Paginar el historial:** si alguien acumula años, cargar todo de golpe.
  Hoy se podan a 60 días, así que no aplica.
- **Cache de respuestas del coach frecuentes:** "¿qué hago primero?" se
  podría cachear unos minutos. Ahorra dinero a gran escala. No urge.

## Veredicto

Para 1,000 e incluso 10,000 usuarios, la arquitectura aguanta sin cambios.
El primer límite que vas a tocar no es la velocidad ni la corrupción: es el
**costo de NVIDIA** (ver `LANZAMIENTO.md`) y, mucho después, el plan de
Supabase. Ninguno es un problema de ingeniería, son de facturación.
