# App de organización — prototipo

## Cómo subirlo a Vercel

1. Ve a https://vercel.com/new
2. Arrastra esta carpeta completa (`app-organizacion/`) o conéctala desde un repo de GitHub.
3. Antes de que termine el despliegue (o después, en Settings), agrega estas variables de entorno:
   - `NVIDIA_API_KEY` → tu llave real de NVIDIA
   - `NVIDIA_MODEL` → (opcional) el modelo que quieras usar. Si lo dejas vacío, usa `meta/llama-3.1-8b-instruct` por defecto.
4. Despliega (o vuelve a desplegar si ya agregaste las variables después).

## Estructura

- `index.html` — la app completa (interfaz, pantallas, lógica de tareas/racha/meta).
- `api/coach.js` — función serverless que recibe las preguntas del coach de IA y le pega a NVIDIA usando tu llave, sin exponerla nunca en el navegador.
- `package.json` — marca el proyecto como módulo ES, necesario para que Vercel acepte el `export default` de la función.

## Notas

- **Historial de hasta 400 días.** El registro guarda un día por llave (`days['2026-07-21']`). De ahí salen la racha, la gráfica de la semana y la navegación con las flechas ‹ ›.
- **La racha se calcula, nunca se guarda** (`calcularRacha()`): cuenta días seguidos con al menos una tarea hecha, perdonando un día. Así no puede desincronizarse del historial real.
- **Flama estilo Duolingo:** la racha se muestra como una flama con degradado y parpadeo (`renderStreak`). Se apaga en gris cuando aún no arrancas ("enciéndela hoy") y marca el día de gracia.
- **Frase de arriba, nueva cada visita:** el texto sobre los anillos (`#insight-text`) muestra **una sola frase por sesión**, elegida al azar cada vez que ENTRAS a la app (carga o regreso a primer plano, vía `elegirInsight`). No rota sola ni cambia al marcar tareas. Sale de un pozo grande (`FRASES_ANIMO` de ánimo + `frasesConDatos()` con tus datos reales) y evita las últimas 15 mostradas (guardadas en `localStorage`), así casi nunca se repite. En días pasados/futuros es fija.
- **Línea de tiempo del día (estilo Structured).** Las tareas se agrupan en momentos —Mañana, Tarde, Noche y "Cuando sea"— con un encabezado de color por sección (`regruparTareas`, `MOMENTOS`). No hay horas ni minutos por tarea: sólo el momento. Cada tarea nace con un momento sugerido por su texto (`momentoSugerido`: "desayunar"→Mañana, "cena"→Noche…) y por defecto cae en "Cuando sea". Se cambia desde el menú de la tarea (⋯ → "Mover a"). La prioridad flota arriba **dentro** de su sección.
- **Carita automática por tarea.** Cada tarea muestra un emoji con fondo de color deducido de su nombre (`iconoParaTarea`/`ICONOS_TAREA`: 🏃 correr, 🛒 despensa, 💻 junta, 💧 agua, 📞 llamada…), sin que el usuario elija nada. Al completarla, la carita se apaga en gris. Se refresca sola al renombrar la tarea.
- **Rachas individuales (una por hábito).** Cada tarea que se repite (cada día/semana/mes) lleva su propia racha, calculada con `rachaDeTarea()` a partir del historial: cuenta las veces que la hiciste, perdona una falla y no se rompe por el hueco natural entre apariciones (una semanal puede tardar hasta 2 semanas). Se ve como una pastilla 🔥N en la tarea (desde 2, sólo en el día de hoy) y como lista "Rachas por hábito" en Estadísticas. Las tareas sueltas no tienen racha: no son hábitos.
- **Historial de 400 días** (`DIAS_GUARDADOS`). Antes eran 60 y cortaba cualquier racha larga; la nube también trae hasta 400.
- **Tiempo en pantalla: sin datos reales no se muestra nada.** Todo lo que lo muestra lleva la clase `solo-pantalla` y el `<body>` arranca con `sin-pantalla`; sólo cuando iOS entrega datos reales (`pantallaReal`) se quita la clase y aparece. El coach recibe `pantalla: null` mientras tanto y tiene prohibido inventar cifras (regla en `api/coach.js`).
- **Instalable en el iPhone sin pagar (PWA).** Abrir la URL en Safari → Compartir → "Agregar a inicio". Los íconos PNG viven en `iconos/` (180/192/512 y maskable); el `sw.js` es **red primero, copia guardada después**: con internet siempre carga lo último que subiste y sin internet abre con la última copia. (Antes era copia primero y la app instalada nunca se actualizaba.) Límites de una PWA: no está en la App Store, no puede leer el tiempo en pantalla real, no cobra con Apple, y las notificaciones son limitadas.
- **Sistema de diseño (todo sale de `:root`; no pongas valores sueltos).**
  - **Texto, 3 niveles + 1:** `--text` (principal), `--text-2` (secundario), `--text-3` (tenue), `--text-4` (apagado/deshabilitado). Nada de `#9a9a9a`, `#6a6a6a`, etc.
  - **Letra, una escala:** `--fs-xs` 11 · `--fs-sm` 13 · `--fs-md` 15 · `--fs-lg` 17 · `--fs-xl` 22 · `--fs-2xl` 28 · `--fs-display` 34. Se usa como `font-size: var(--fs-sm)`. Excepciones a propósito: tamaños de iconos (`<i class="ti">` y reglas `svg`), el emoji de la tarea (19px) y los campos de texto (16px, para que iOS no haga zoom al enfocar).
  - **Esquinas:** `--r-sm` 12 · `--r-md` 16 · `--r-lg` 22 (más `50%` para círculos y pastillas).
  - **Fondos y bordes:** `--glass` / `--glass-strong` (superficies), `--hairline` (borde fino), `--hairline-2` (borde resaltado o punteado), `--track` (pista vacía de anillos y barras).
  - **Colores con significado, fijos a propósito:** el acento (`--accent`, lo elige el usuario), el degradado del coach, el fuego de la racha, el semáforo de tareas, ámbar de aviso, rojo de borrar.
  - **Ojo con SVG:** `fill`/`stroke` como atributo NO aceptan `var(--...)`; usa `style="fill:var(--text)"`. Y una etiqueta nunca debe tener dos atributos `style` (el navegador ignora el segundo).
- **Tiempo de enfoque.** Lo único "recuperado" que la app puede medir de verdad: los segundos que corrió el cronómetro del modo enfoque (`registrarEnfoque`, un tick de 1 s con el reloj andando; pausar no suma, y si el sistema duerme la página suma de menos, nunca de más). Se guarda por día en `registro.enfoque[iso]` (aparte de `days`, **no se sincroniza todavía**; `fusionar` lo conserva porque parte de una copia del registro local) y se poda con el historial. Se muestra como una línea en Hoy ("🎯 25 min de enfoque hoy", desde 30 s) y como tarjeta arriba en Estadísticas (semana, hoy y total). El coach recibe `enfoque.hoyMin/semanaMin` y tiene prohibido decir que estuvo "lejos del celular". **El "tiempo recuperado" literal (cuánto menos pantalla que antes) sólo será posible con el tiempo en pantalla real de iOS.**
- **Gratis vs plan (`LIMITES_GRATIS`, `COBRO_ABIERTO`).** Gratis: 5 tareas al día, 5 mensajes al día con el coach, 3 hábitos (tareas que se repiten, cada una con su racha), agenda hasta 7 días hacia adelante, navegar los últimos 30 días de historial (los datos se guardan igual, sólo se limita verlos) y 3 colores. Racha general, línea de tiempo, modo enfoque y sincronización no se bloquean. Todo está en un solo objeto, así que cambiar un número cambia el tope y también el texto de la pantalla del plan. **`COBRO_ABIERTO = false` mientras no exista la compra real: todos tienen todo.** Cuando exista el cobro, ponerlo en `true` y que la compra marque `registro.premium = true` (el recibo debe validarse en servidor; el tope del cliente sólo cuida la experiencia, no es seguridad). La pantalla del plan se arma sola desde esa configuración.
- **Eliminar cuenta:** Configuración → Tu cuenta → "Eliminar mi cuenta" (doble confirmación). Llama a la función SQL `borrar_mi_cuenta()` de `supabase/schema.sql`; hay que correr ese SQL en Supabase.
- Los **días pasados son de sólo lectura**. Son un registro de lo que hiciste, no una lista editable.
- Al abrir un día nuevo, se arrastran las tareas del día anterior sin marcar (menos las recurrentes, que las decide su propia regla).
- **Tareas que se repiten.** Al agregar una tarea eliges: una vez, cada día, cada semana o cada mes. Se guardan como plantillas (`registro.recurrentes`) y reaparecen solas el día que toca: la semanal el mismo día de la semana, la mensual el mismo número de día (un "31" cae el último día de los meses cortos). Al eliminar una recurrente, se pregunta si quitarla sólo hoy o dejar de repetirla.
- **Captura rápida (volcado mental).** Botón flotante (+) siempre visible: sueltas una idea sin navegar y sigues. Entiende fechas por lenguaje natural ("comprar pan mañana", "pagar el 30", "llamar el viernes") con `extraerFecha`.
- **Agendar a futuro.** Las tareas con fecha van a su día. Puedes navegar con las flechas a los días futuros (editables) y a los pasados (sólo lectura). El día de hoy avisa "N programadas para después →". Cuando un día programado se vuelve hoy, sus tareas ya están ahí y además se arrastran las pendientes de ayer (una sola vez, con `ultimoArrastre`).
- Todo se guarda en `localStorage` del navegador. Es por dispositivo: **no se sincroniza** entre teléfono y computadora.
- Si `NVIDIA_API_KEY` no está configurada (o NVIDIA falla), el coach responde con mensajes de ejemplo en vez de mostrar un error.
- El coach entiende comandos: "agrega una tarea de X", "ya hice X", "límite de 3h", "meta de 7".

## Onboarding y perfil

- La primera vez, 5 pasos (nombre, qué se te complica, qué quieres lograr, cuándo rindes mejor, y tus horarios) que se guardan en `registro.perfil`.
- **Horarios con rueda tipo scroll:** el último paso pregunta a qué hora te despiertas y te acuestas con dos selectores deslizables en pasos de 15 min (`construirPicker`/`posicionarPicker`, con scroll-snap). Se guardan como `despierta`/`duerme` y el coach los usa para acomodar tu día.
- Ese perfil **alimenta al coach**: aparece en `construirMetrics().perfil` (para el coach en la nube) y el coach local lo usa en la rama de recomendaciones ("recomiéndame", "cómo me organizo", "cómo cumplo mi meta").
- Al terminar, el coach saluda personalizado con un primer consejo a la medida.
- Se puede rehacer en Perfil → engranaje → "Volver a conocerme" (precarga lo que ya contestaste).

## Cómo funciona el coach

- **Responde del tamaño de lo que le preguntas.** Un "hola" se contesta con un "hola", no con un reporte del día. Sólo se extiende si le pides un plan.
- **Se toma su tiempo.** Aunque la respuesta ya esté lista, deja los puntitos de "escribiendo" un momento y luego escribe palabra por palabra. Se ajusta en `MIN_PENSANDO` y `MS_POR_PALABRA` dentro de `index.html`. Si el sistema pide menos animación (`prefers-reduced-motion`), aparece de golpe.
- La primera vez pregunta tu nombre y lo guarda. También puedes escribirlo en Perfil, y el coach lo puede cambiar con la acción `set_name`.
- Se le manda la **conversación completa** del día, no sólo el último mensaje, así que recuerda de qué estaban hablando.
- Puede **cambiar cosas en la app**, no sólo contestar. El modelo responde un JSON `{"reply": "...", "actions": [...]}` y la app ejecuta las acciones: `add_task`, `complete_task`, `remove_task`, `set_goal`, `set_limit`.
- La conversación se guarda junto con el resto del día y se borra sola al día siguiente.
- **Sin `NVIDIA_API_KEY` no hay plática real.** Entra un coach local que entiende saludos, "organiza mi día", pantalla, racha, cansancio y los comandos de arriba, usando tus datos reales. Es útil, pero no conversa: para eso hay que configurar la llave y desplegar.
- El modelo por defecto es `meta/llama-3.3-70b-instruct`. Uno más chico (como `llama-3.1-8b`) tiende a romper el formato JSON y a ignorar instrucciones; si lo cambias, pruébalo pidiéndole que agregue una tarea.
- En **Perfil → engranaje** está Configuración: nombre, correo, teléfono, recordatorios y el botón para borrar todos tus datos.
- Tu correo y teléfono se guardan **sólo en tu navegador** (`localStorage`), no se mandan a ningún servidor. Los recordatorios todavía no envían nada: guardan tu preferencia, pero falta conectar notificaciones reales.
- Los iconos son SVG incrustados en el propio `index.html` (no se cargan de un CDN), así que la app se ve completa aunque no haya internet. Para agregar un icono nuevo, añade su path al objeto `ICONS` y úsalo como `<i class="ti ti-nombre"></i>`.
- El tiempo en pantalla real sólo existe en la app nativa de iOS; en web está oculto (ver arriba). Las cifras de ejemplo que siguen en el HTML nunca se muestran ni llegan al coach.
