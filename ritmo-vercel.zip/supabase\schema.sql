-- ============================================================
-- Esquema de la base de datos
--
-- Cópialo completo y pégalo en Supabase → SQL Editor → Run.
-- Se puede volver a correr sin romper nada.
--
-- LO MÁS IMPORTANTE DE ESTE ARCHIVO son las políticas RLS del
-- final. Sin ellas, CUALQUIERA con la llave pública de tu app
-- podría leer las tareas y el teléfono de todos tus usuarios.
-- Con ellas, la base de datos misma impide que un usuario vea
-- los datos de otro, aunque tu código tuviera un error.
-- ============================================================

-- ------------------------------------------------------------
-- Perfil: los datos de la persona y sus preferencias
-- ------------------------------------------------------------
create table if not exists public.perfiles (
  id           uuid primary key references auth.users on delete cascade,
  nombre       text,
  telefono     text,
  meta_diaria  smallint not null default 5,
  limite_horas smallint not null default 4,
  config       jsonb    not null default '{}'::jsonb,
  actualizado  timestamptz not null default now()
);

comment on table public.perfiles is 'Un renglón por usuario. El correo no se guarda aquí: ya vive en auth.users.';

-- ------------------------------------------------------------
-- Días: un renglón por usuario y por fecha
-- ------------------------------------------------------------
create table if not exists public.dias (
  usuario_id  uuid not null references auth.users on delete cascade,
  fecha       date not null,
  tareas      jsonb not null default '[]'::jsonb,
  actualizado timestamptz not null default now(),
  primary key (usuario_id, fecha)
);

-- Para que "dame los últimos 60 días" sea rápido.
create index if not exists dias_por_usuario_fecha
  on public.dias (usuario_id, fecha desc);

-- ------------------------------------------------------------
-- Al registrarse, se crea su perfil solo
-- ------------------------------------------------------------
create or replace function public.crear_perfil_nuevo()
returns trigger
language plpgsql
security definer
set search_path = ''   -- vacío a propósito: nada se resuelve "por sorpresa"; todo va calificado
as $$
begin
  insert into public.perfiles (id) values (new.id)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists al_crear_usuario on auth.users;
create trigger al_crear_usuario
  after insert on auth.users
  for each row execute function public.crear_perfil_nuevo();

-- ------------------------------------------------------------
-- Marca de tiempo automática: la usa la app para decidir qué
-- versión gana cuando editaste en dos teléfonos.
-- ------------------------------------------------------------
create or replace function public.marcar_actualizado()
returns trigger
language plpgsql
as $$
begin
  new.actualizado = now();
  return new;
end;
$$;

drop trigger if exists perfiles_actualizado on public.perfiles;
create trigger perfiles_actualizado
  before update on public.perfiles
  for each row execute function public.marcar_actualizado();

drop trigger if exists dias_actualizado on public.dias;
create trigger dias_actualizado
  before update on public.dias
  for each row execute function public.marcar_actualizado();

-- ============================================================
-- SEGURIDAD POR RENGLÓN (RLS)
-- Sin esto, todo lo de arriba es una base de datos pública.
-- ============================================================

alter table public.perfiles enable row level security;
alter table public.dias     enable row level security;

-- Cada quien ve y escribe únicamente su propio perfil.
drop policy if exists "perfil propio" on public.perfiles;
create policy "perfil propio" on public.perfiles
  for all
  to authenticated
  using      (auth.uid() = id)
  with check (auth.uid() = id);

-- Cada quien ve y escribe únicamente sus propios días.
drop policy if exists "dias propios" on public.dias;
create policy "dias propios" on public.dias
  for all
  to authenticated
  using      (auth.uid() = usuario_id)
  with check (auth.uid() = usuario_id);

-- ============================================================
-- LÍMITES Y DEFENSA EN PROFUNDIDAD
-- RLS ya impide ver datos de otros, pero un usuario con sesión podría
-- llenar la base con basura (miles de días, textos gigantes) y tumbar tu
-- plan gratis de Supabase. Estos límites lo impiden, y de paso rechazan
-- datos con forma imposible.
-- ============================================================

-- El público anónimo no tiene por qué tocar estas tablas NI SIQUIERA si
-- algún día alguien rompe una política: sin permiso, no hay acceso.
revoke all on table public.perfiles from anon;
revoke all on table public.dias from anon;

alter table public.perfiles drop constraint if exists perfiles_limites;
alter table public.perfiles add constraint perfiles_limites check (
  (nombre is null or char_length(nombre) <= 60)
  and (telefono is null or char_length(telefono) <= 30)
  and meta_diaria between 1 and 50
  and limite_horas between 1 and 24
  and octet_length(config::text) <= 4000
);

alter table public.dias drop constraint if exists dias_limites;
alter table public.dias add constraint dias_limites check (
  jsonb_typeof(tareas) = 'array'
  and octet_length(tareas::text) <= 60000
  and fecha between date '2020-01-01' and date '2100-01-01'
);

-- Tope de días por cuenta. La app guarda ~400 días y deja agendar al futuro;
-- 1500 deja de sobra y frena a quien intente guardar miles. (Se corre con
-- los permisos de quien llama: RLS ya limita el conteo a sus propias filas.)
create or replace function public.limitar_dias_por_usuario()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if (select count(*) from public.dias where usuario_id = new.usuario_id) >= 1500 then
    raise exception 'Límite de días por cuenta alcanzado';
  end if;
  return new;
end;
$$;

drop trigger if exists dias_limite on public.dias;
create trigger dias_limite
  before insert on public.dias
  for each row execute function public.limitar_dias_por_usuario();

-- ============================================================
-- BORRAR MI CUENTA (requisito de Apple)
-- Un navegador no puede borrar usuarios de auth.users (con razón). Esta
-- función corre con permisos de dueño pero SÓLO borra al usuario que la
-- llama (auth.uid()), nunca a otro. Como perfiles y dias referencian a
-- auth.users con "on delete cascade", también se va todo lo suyo.
-- Devuelve true (y no void) para que la respuesta HTTP traiga cuerpo.
-- ============================================================
create or replace function public.borrar_mi_cuenta()
returns boolean
language plpgsql
security definer
set search_path = ''   -- vacío a propósito: todo va calificado (auth.users, auth.uid())
as $$
begin
  if auth.uid() is null then
    raise exception 'No hay sesión iniciada';
  end if;
  delete from auth.users where id = auth.uid();
  return true;
end;
$$;

-- Sólo usuarios con sesión pueden llamarla; el público anónimo no.
revoke all on function public.borrar_mi_cuenta() from public, anon;
grant execute on function public.borrar_mi_cuenta() to authenticated;

-- ============================================================
-- CÓMO COMPROBAR QUE QUEDÓ BIEN
--
-- Corre esto. Las dos tablas deben decir rowsecurity = true:
--
--   select tablename, rowsecurity
--   from pg_tables
--   where schemaname = 'public' and tablename in ('perfiles','dias');
--
-- Si alguna dice false, NO subas la app: los datos estarían
-- abiertos a cualquiera.
-- ============================================================
