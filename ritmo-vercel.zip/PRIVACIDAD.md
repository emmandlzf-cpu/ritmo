# Aviso de privacidad

**Última actualización:** 21 de julio de 2026

> ⚠️ **Antes de publicar:** este es un borrador honesto de lo que la app hace **hoy**.
> Si agregas cuentas, analítica, notificaciones push o sincronización en la nube,
> este documento deja de ser cierto y hay que actualizarlo. Declarar en App Store
> Connect algo distinto a lo que la app realmente hace es causa de rechazo — y de
> problemas legales más serios que un rechazo.
>
> Apple exige que esto viva en una **URL pública** (no un archivo suelto).
> Súbelo como `privacidad.html` en el mismo dominio de Vercel.

---

## Quién es responsable

[TU NOMBRE O RAZÓN SOCIAL]
Contacto: [TU CORREO DE SOPORTE]

## Qué información recogemos

**Lo que tú escribes en la app:**

- Tu nombre, correo y teléfono, si decides ponerlos en Configuración.
- Tus tareas y si las completaste.
- Tu meta diaria y tu límite de tiempo en pantalla.
- Tu conversación con el coach.

**No recogemos:** tu ubicación, tus contactos, tus fotos, ni identificadores de
publicidad. La app no tiene anuncios ni rastreadores.

## Dónde se guarda

**Sin cuenta:** todo vive únicamente en el almacenamiento local de tu
dispositivo. No tenemos copia de nada.

**Con cuenta:** si decides entrar con tu correo para sincronizar entre
dispositivos, guardamos en nuestra base de datos:

- Tu correo electrónico (para identificarte y mandarte el enlace de acceso).
- Tus tareas y su estado, día por día.
- Tu nombre, tu teléfono, tu meta diaria y tu límite de pantalla, si los
  configuraste.

Esa información se guarda en **Supabase**, nuestro proveedor de base de datos,
y está protegida para que **cada cuenta sólo pueda acceder a sus propios
datos**. Ni siquiera con la llave pública de la app se pueden leer los datos de
otra persona.

Política de Supabase: <https://supabase.com/privacy>

**Crear una cuenta es opcional.** La app funciona completa sin ella; sólo
pierdes la sincronización entre dispositivos.

## La única información que sale de tu dispositivo

Cuando le escribes al coach, se envía a nuestro servidor y de ahí a
**NVIDIA** (proveedor del modelo de inteligencia artificial) lo siguiente:

- El texto de tu mensaje y los mensajes anteriores de esa conversación.
- Un resumen de tu día: cuántas tareas llevas, tu tiempo en pantalla, tu racha,
  tu meta y tu nombre de pila si lo configuraste.

Esto es necesario para que el coach pueda responderte con tus datos reales.
**No enviamos tu correo ni tu teléfono.** No guardamos esas conversaciones en
ningún servidor nuestro: pasan, se responden y no se almacenan.

El manejo que NVIDIA hace de esa información se rige por sus propios términos:
<https://www.nvidia.com/en-us/about-nvidia/privacy-policy/>

Si no quieres que nada salga de tu teléfono, simplemente no uses la sección
Coach; el resto de la app funciona sin conexión.

## Menores de edad

Esta app no está dirigida a menores de 13 años y no recogemos información de
ellos a sabiendas.

## Tus derechos

Como todo vive en tu dispositivo, tú tienes el control directo:

- **Ver tus datos:** están en la app, en Perfil y Configuración.
- **Corregirlos:** edítalos ahí mismo.
- **Borrarlos de este dispositivo:** Configuración → "Borrar todos mis datos".
- **Borrar tu cuenta y todo lo que tenemos de ti:** escríbenos a
  [TU CORREO DE SOPORTE] y lo hacemos dentro de los 30 días siguientes.

> ⚠️ **Pendiente antes de publicar en la App Store:** Apple **exige** que el
> borrado de cuenta se pueda hacer **desde dentro de la app**, no sólo por
> correo. Hoy la app no lo tiene. Hay que agregarlo o rechazan la publicación.

Si tienes dudas, escríbenos a [TU CORREO DE SOPORTE].

## Cambios a este aviso

Si cambiamos algo, actualizaremos la fecha de arriba y te avisaremos dentro de
la app antes de que aplique.
