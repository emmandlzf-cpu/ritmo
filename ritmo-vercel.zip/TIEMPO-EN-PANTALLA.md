# Tiempo en pantalla — qué está listo y qué falta

Esta es tu función estrella y la más difícil. Aquí está el estado honesto.

## Lo que YA está listo (el lado de la app)

La app web ya sabe consumir tiempo en pantalla real. En cuanto el lado
nativo se lo entregue, la pantalla de Estadísticas se llena sola y el coach
empieza a usar datos reales. No hay que tocar la interfaz.

- **`screentime.js`** — el contrato entre la app y el código nativo. Define
  la forma exacta de los datos. Ya probado: si le llegan datos reales, la
  pantalla los muestra; si no (en web), se queda el ejemplo etiquetado.
- **La pantalla de Estadísticas** detecta sola si hay datos reales:
  - En un navegador → muestra el ejemplo con la etiqueta "datos de ejemplo".
  - En la app de iOS sin permiso → botón "Conectar tiempo en pantalla".
  - Con permiso dado → datos reales, sin etiqueta.
- **`ios-nativo/ScreenTimePlugin.swift` y `.m`** — el andamiaje del plugin
  nativo, con la estructura y los permisos correctos.

## Lo que FALTA (el lado nativo, necesita Mac + Xcode + Apple)

Esto no se puede hacer desde aquí. Necesita una Mac, Xcode, un iPhone físico
y —lo más lento— la aprobación de Apple.

### 1. El entitlement de Family Controls (semanas de espera)
Apple protege el tiempo en pantalla. Para leerlo necesitas pedir el permiso
especial **Family Controls (Distribution)** en:
<https://developer.apple.com/contact/request/family-controls-distribution>

Le explicas a Apple para qué lo quieres. Lo aprueban caso por caso y **puede
tardar semanas o negarse**. Sin esto, la app ni siquiera compila con la
función activada. Empieza este trámite pronto: es el que manda en el
calendario.

### 2. La extensión que cuenta el tiempo
Apple no le da los totales directo a la app. Hay que crear una **App
Extension de tipo DeviceActivityReport** que:
1. Calcula el tiempo por app.
2. Lo guarda en un App Group compartido.
3. El plugin (`ScreenTimePlugin.swift`) lo lee de ahí.

Esa extensión es un archivo Swift que todavía falta escribir. El plugin ya
está listo para leer lo que ella deje.

### 3. Probarlo en un iPhone de verdad
FamilyControls **no funciona en el simulador**. Necesitas un iPhone físico
para probar.

## Lo que Apple NO te deja hacer

Ojo con esto para no diseñar de más:

- **No puedes mostrar "Instagram 58%" con nombre y logo** como en el ejemplo
  de hoy. Apple entrega los datos de forma protegida: categorías y tokens
  opacos, con el usuario autorizando. La pantalla habrá que ajustarla a lo
  que la API sí entrega. El ejemplo de hoy es más detallado de lo que será
  posible — tenlo en cuenta.
- **No puedes leerlo en segundo plano cuando quieras.** Hay reglas sobre
  cuándo y cómo.

## En resumen

- **Listo:** toda la app web, lista para recibir datos reales.
- **Falta:** el trámite con Apple (empiézalo ya), la extensión Swift que
  cuenta el tiempo, y probarlo en un iPhone.
- **Realista:** es un proyecto de varias semanas dominado por los tiempos de
  Apple, no por el código.
